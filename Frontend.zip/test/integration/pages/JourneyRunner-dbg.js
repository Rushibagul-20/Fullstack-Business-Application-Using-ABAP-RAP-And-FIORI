sap.ui.define([
    "sap/fe/test/JourneyRunner",
	"zrap100200/test/integration/pages/TravelList",
	"zrap100200/test/integration/pages/TravelObjectPage"
], function (JourneyRunner, TravelList, TravelObjectPage) {
    'use strict';

    var runner = new JourneyRunner({
        launchUrl: sap.ui.require.toUrl('zrap100200') + '/test/flpSandbox.html#zrap100200-tile',
        pages: {
			onTheTravelList: TravelList,
			onTheTravelObjectPage: TravelObjectPage
        },
        async: true
    });

    return runner;
});

